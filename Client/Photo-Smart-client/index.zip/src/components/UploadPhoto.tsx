const UploadPhoto=()=>{
    return(<>
    <h2>Upload Photo</h2>
    </>)
}
export default UploadPhoto;