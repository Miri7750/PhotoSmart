export interface Photo {
    id: string;
    albumId: string;
    url: string;
    tags: string[];
    date: string;
}