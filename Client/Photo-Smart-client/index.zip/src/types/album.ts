export interface Album {
    id: string;
    title: string;
    description: string;
}


